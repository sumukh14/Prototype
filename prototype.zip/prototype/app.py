from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, send_from_directory
import json
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'

# Sample data structure
BRANCHES = ['Computer Science', 'Electronics', 'Mechanical', 'Civil', 'Electrical']
YEARS = ['1st Year', '2nd Year', '3rd Year', '4th Year']
SUBJECTS = {
    'Computer Science': {
        '1st Year': ['Mathematics', 'Physics', 'Chemistry', 'Programming Fundamentals'],
        '2nd Year': ['Data Structures', 'Algorithms', 'Database Systems', 'Operating Systems'],
        '3rd Year': ['Machine Learning', 'Computer Networks', 'Software Engineering', 'Web Development'],
        '4th Year': ['Cloud Computing', 'Cybersecurity', 'AI & Deep Learning', 'Project Management']
    },
    'Electronics': {
        '1st Year': ['Mathematics', 'Physics', 'Chemistry', 'Basic Electronics'],
        '2nd Year': ['Digital Electronics', 'Analog Circuits', 'Signals & Systems', 'Microprocessors'],
        '3rd Year': ['VLSI Design', 'Communication Systems', 'Control Systems', 'Embedded Systems'],
        '4th Year': ['IoT', 'RF Engineering', 'Power Electronics', 'Project Management']
    },
    'Mechanical': {
        '1st Year': ['Mathematics', 'Physics', 'Chemistry', 'Engineering Drawing'],
        '2nd Year': ['Thermodynamics', 'Mechanics', 'Materials Science', 'Manufacturing'],
        '3rd Year': ['Heat Transfer', 'Machine Design', 'CAD/CAM', 'Fluid Mechanics'],
        '4th Year': ['Automotive Engineering', 'Robotics', 'Renewable Energy', 'Project Management']
    },
    'Civil': {
        '1st Year': ['Mathematics', 'Physics', 'Chemistry', 'Engineering Drawing'],
        '2nd Year': ['Structural Analysis', 'Surveying', 'Building Materials', 'Fluid Mechanics'],
        '3rd Year': ['Reinforced Concrete', 'Steel Structures', 'Transportation', 'Environmental Engineering'],
        '4th Year': ['Construction Management', 'Geotechnical Engineering', 'Urban Planning', 'Project Management']
    },
    'Electrical': {
        '1st Year': ['Mathematics', 'Physics', 'Chemistry', 'Basic Electrical'],
        '2nd Year': ['Circuit Analysis', 'Electromagnetic Fields', 'Power Systems', 'Electrical Machines'],
        '3rd Year': ['Power Electronics', 'Control Systems', 'Renewable Energy', 'High Voltage Engineering'],
        '4th Year': ['Smart Grid', 'Power System Protection', 'Energy Management', 'Project Management']
    }
}

# Sample notes and papers data
def load_data():
    data_file = 'data.json'
    if os.path.exists(data_file):
        with open(data_file, 'r') as f:
            return json.load(f)
    return {
        'notes': [],
        'papers': []
    }

def save_data(data):
    with open('data.json', 'w') as f:
        json.dump(data, f, indent=2)

def init_sample_data():
    data = load_data()
    if not data['notes']:
        data['notes'] = [
            {
                'id': 1,
                'title': 'Data Structures - Complete Notes',
                'subject': 'Data Structures',
                'branch': 'Computer Science',
                'year': '2nd Year',
                'uploaded_by': 'John Doe',
                'upload_date': '2024-01-15',
                'downloads': 245,
                'rating': 4.8,
                'file_type': 'PDF',
                'location': 'et_cse_4th_dsa.pdf+'
            },
            {
                'id': 2,
                'title': 'Computer Architechture and Organization',
                'subject': 'Algorithms',
                'branch': 'Computer Science',
                'year': '2nd Year',
                'uploaded_by': 'SARTHAK SINGH RATHORE',
                'upload_date': '2024-01-20',
                'downloads': 189,
                'rating': 4.6,
                'file_type': 'PDF',
                'location': 'CO (BCSC1005)_end term_2024-25.pdf'
            },
            {
                'id': 3,
                'title': 'Operating Systems',
                'subject': 'Computer Science',
                'branch': 'Computer Science',
                'year': '2nd Year',
                'uploaded_by': 'SARTHAK SINGH RATHORE',
                'upload_date': '2024-02-01',
                'downloads': 312,
                'rating': 4.9,
                'file_type': 'PDF',
                'location': 'OS_MID TERM_Sec_A.pdf'
            }
        ]
    if not data['papers']:
        data['papers'] = [
            {
                'id': 1,
                'title': 'Data Structures - 2025 Final Exam',
                'subject': 'Data Structures',
                'branch': 'Computer Science',
                'year': '2nd Year',
                'exam_year': 2023,
                'uploaded_by': 'Admin',
                'upload_date': '2024-01-10',
                'downloads': 456,
                'file_type': 'PDF',
                'location': 'et_cse_4th_dsa.pdf'
            },
            {
                'id': 2,
                'title': 'Computer Architecture and organization - 2025 Midterm Exam',
                'subject': 'Algorithms',
                'branch': 'Computer Science',
                'year': '2nd Year',
                'exam_year': 2022,
                'uploaded_by': 'Admin',
                'upload_date': '2024-01-10',
                'downloads': 389,
                'file_type': 'PDF',
                'location': 'CO (BCSC1005)_end term_2024-25.pdf'
            },
            {
                'id': 3,
                'title': 'Operating Systems - 2025 Final Exam',
                'subject': 'Database Systems',
                'branch': 'Computer Science',
                'year': '2nd Year',
                'exam_year': 2023,
                'uploaded_by': 'Admin',
                'upload_date': '2024-01-10',
                'downloads': 521,
                'file_type': 'PDF',
                'location': 'OS_MID TERM_Sec_A.pdf'
            }
        ]
    else:
        # Add location field to existing items if missing
        for item in data['notes']:
            if 'location' not in item:
                branch_code = item.get('branch', '').lower().replace(' ', '_')
                year_code = item.get('year', '').lower().replace(' ', '_')
                subject_code = item.get('subject', '').lower().replace(' ', '_')
                title_code = item.get('title', '').lower().replace(' ', '_')
                item['location'] = f'/uploads/notes/{branch_code}/{year_code}/{title_code}.pdf'
        
        for item in data['papers']:
            if 'location' not in item:
                branch_code = item.get('branch', '').lower().replace(' ', '_')
                year_code = item.get('year', '').lower().replace(' ', '_')
                subject_code = item.get('subject', '').lower().replace(' ', '_')
                title_code = item.get('title', '').lower().replace(' ', '_')
                item['location'] = f'/uploads/papers/{branch_code}/{year_code}/{title_code}.pdf'
    
    save_data(data)
    return data

@app.route('/')
def index():
    data = load_data()
    return render_template('index.html', 
                         branches=BRANCHES,
                         years=YEARS,
                         stats={
                             'total_notes': len(data['notes']),
                             'total_papers': len(data['papers']),
                             'total_users': 1250,
                             'total_downloads': sum(n.get('downloads', 0) for n in data['notes']) + 
                                              sum(p.get('downloads', 0) for p in data['papers'])
                         })

@app.route('/browse')
def browse():
    branch = request.args.get('branch', '')
    year = request.args.get('year', '')
    resource_type = request.args.get('type', 'notes')  # 'notes' or 'papers'
    search = request.args.get('search', '')
    
    data = load_data()
    items = data[resource_type]
    
    # Filter by branch and year
    if branch:
        items = [item for item in items if item.get('branch') == branch]
    if year:
        items = [item for item in items if item.get('year') == year]
    
    # Search filter
    if search:
        search_lower = search.lower()
        items = [item for item in items if search_lower in item.get('title', '').lower() or 
                search_lower in item.get('subject', '').lower()]
    
    subjects = SUBJECTS.get(branch, {}).get(year, []) if branch and year else []
    
    return render_template('browse.html',
                         items=items,
                         resource_type=resource_type,
                         branches=BRANCHES,
                         years=YEARS,
                         subjects=subjects,
                         selected_branch=branch,
                         selected_year=year,
                         search_query=search)

@app.route('/contribute', methods=['GET', 'POST'])
def contribute():
    if request.method == 'POST':
        resource_type = request.form.get('resource_type')
        title = request.form.get('title')
        subject = request.form.get('subject')
        branch = request.form.get('branch')
        year = request.form.get('year')
        uploaded_by = request.form.get('uploaded_by', 'Anonymous')
        location = request.form.get('location', '').strip()
        
        data = load_data()
        new_id = max([item.get('id', 0) for item in data[resource_type]], default=0) + 1
        
        # Generate location if not provided
        if not location:
            branch_code = branch.lower().replace(' ', '_')
            year_code = year.lower().replace(' ', '_')
            title_code = title.lower().replace(' ', '_').replace('/', '_')
            location = f'/uploads/{resource_type}/{branch_code}/{year_code}/{title_code}.pdf'
        
        new_item = {
            'id': new_id,
            'title': title,
            'subject': subject,
            'branch': branch,
            'year': year,
            'uploaded_by': uploaded_by,
            'upload_date': datetime.now().strftime('%Y-%m-%d'),
            'downloads': 0,
            'file_type': 'PDF',
            'location': location
        }
        
        if resource_type == 'notes':
            new_item['rating'] = 0.0
        else:
            new_item['exam_year'] = int(request.form.get('exam_year', datetime.now().year))
        
        data[resource_type].append(new_item)
        save_data(data)
        
        flash(f'Thank you for contributing! Your {resource_type[:-1]} has been submitted.', 'success')
        return redirect(url_for('browse', type=resource_type, branch=branch, year=year))
    
    return render_template('contribute.html',
                         branches=BRANCHES,
                         years=YEARS)

@app.route('/api/subjects')
def get_subjects():
    branch = request.args.get('branch')
    year = request.args.get('year')
    if branch and year:
        subjects = SUBJECTS.get(branch, {}).get(year, [])
        return jsonify(subjects)
    return jsonify([])

@app.route('/download/<resource_type>/<int:item_id>')
def download(resource_type, item_id):
    data = load_data()
    items = data.get(resource_type, [])
    item = next((i for i in items if i.get('id') == item_id), None)
    
    if not item:
        flash('Resource not found.', 'error')
        return redirect(url_for('browse', type=resource_type))
    
    # Increment download count
    item['downloads'] = item.get('downloads', 0) + 1
    save_data(data)
    
    location = item.get('location', '')
    if location.startswith('http://') or location.startswith('https://'):
        # External URL - redirect
        return redirect(location)
    else:
        # Local file path - serve the file
        # Handle both relative paths (database/file.pdf) and absolute paths (/uploads/...)
        if location.startswith('/'):
            location = location[1:]  # Remove leading slash
        
        if os.path.exists(location):
            # Split path into directory and filename
            directory = os.path.dirname(location) or '.'
            filename = os.path.basename(location)
            return send_from_directory(directory, filename, as_attachment=True)
        else:
            flash(f'File not found: {location}', 'error')
            return redirect(url_for('browse', type=resource_type))

if __name__ == '__main__':
    init_sample_data()
    app.run(debug=True, port=5000)
