# Unified Academic Hub

A high-fidelity prototype for a Unified Academic Hub that solves the problem of fragmented study resources in colleges. This platform provides easy access to notes, previous year papers, and study materials all in one place.

## Features

- **Easy Access**: Quick branch and year selector for instant navigation
- **Fast Discovery**: Powerful search and filter system to find resources quickly
- **Stress-Free Exam Prep**: Access to comprehensive notes and previous year papers
- **Clean Dashboard**: Modern, intuitive interface with statistics and quick access
- **Student Contribution Model**: Students can contribute their own notes and papers

## Tech Stack

- **Backend**: Python with Flask
- **Frontend**: HTML, CSS (Tailwind CSS via CDN), JavaScript
- **Data Storage**: JSON file (easily replaceable with a database)

## Installation

1. **Install Python dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Run the application:**
   ```bash
   python app.py
   ```

3. **Access the application:**
   Open your browser and navigate to `http://localhost:5000`

## Project Structure

```
prototype/
├── app.py                 # Flask application and routes
├── requirements.txt       # Python dependencies
├── data.json             # Data storage (auto-generated)
├── templates/            # HTML templates
│   ├── base.html        # Base template with navigation
│   ├── index.html       # Homepage/dashboard
│   ├── browse.html      # Browse notes and papers
│   └── contribute.html  # Contribution form
└── README.md            # This file
```

## Usage

### Homepage
- View statistics (total notes, papers, users, downloads)
- Use quick branch and year selector
- Navigate to notes or previous year papers

### Browse
- Filter by branch, year, and subject
- Search for specific resources
- Switch between notes and papers
- View download counts and ratings

### Contribute
- Submit study notes or previous year papers
- Fill in branch, year, and subject information
- Help build the community resource library

## Features in Detail

### Branch & Year Selector
- Quick access dropdowns on homepage
- Filters applied automatically when browsing
- Dynamic subject loading based on selection

### Notes & Previous Year Papers
- Comprehensive browsing interface
- Advanced filtering options
- Download tracking and ratings
- Clean card-based layout

### Clean Dashboard
- Statistics overview
- Feature highlights
- Quick navigation
- Modern gradient design

### Student Contribution Model
- Easy submission form
- Support for both notes and papers
- Guidelines and best practices
- Community-driven content

## Customization

### Adding New Branches/Subjects
Edit the `SUBJECTS` dictionary in `app.py` to add new branches or modify subjects.

### Styling
The application uses Tailwind CSS via CDN. Modify the classes in the HTML templates to customize the appearance.

### Data Storage
Currently uses JSON file storage. For production, replace with a database (SQLite, PostgreSQL, etc.) by modifying the `load_data()` and `save_data()` functions.

## Future Enhancements

- User authentication and profiles
- File upload functionality
- Rating and review system
- Advanced search with full-text search
- Download tracking and analytics
- Email notifications
- Mobile app version

## License

This is a prototype project for hackathon/project evaluation purposes.
